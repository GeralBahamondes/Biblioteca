import { StyleSheet} from "react-native";
import 'react-native-gesture-handler';

import { createStackNavigator } from "@react-navigation/stack";
import { NavigationContainer } from "@react-navigation/native";
import home from "./screens/home";
import login from "./screens/login";
import reserva from "./screens/reserva";
import libros from "./screens/libros";
import historial from "./screens/historial";

export default function App() {

  const Stack = createStackNavigator();

  function MyStack() {
    return (
      <Stack.Navigator>
        <Stack.Screen name="Login" component={login} 
        options={{
          title: "Biblioteca Lago Ranco",
          headerTintColor: "white",
          headerTitleAlign: "center",
          headerStyle: { backgroundColor: "#525FE1"}
        }
        }/>
        <Stack.Screen name="Home" component={home} 
        options={{
          title: "Bienvenido",
          headerTintColor: "white",
          headerTitleAlign: "center",
          headerStyle: { backgroundColor: "#525FE1"}
        }
        }/>
        <Stack.Screen name="Reserva" component={reserva} 
        options={{
          title: "Bienvenido",
          headerTintColor: "white",
          headerTitleAlign: "center",
          headerStyle: { backgroundColor: "#525FE1"}
        }}/>
        <Stack.Screen name="Libros" component={libros} 
        options={{
          title: "Bienvenido",
          headerTintColor: "white",
          headerTitleAlign: "center",
          headerStyle: { backgroundColor: "#525FE1"}
        }}/>
        <Stack.Screen name="Historial" component={historial} 
        options={{
          title: "Bienvenido",
          headerTintColor: "white",
          headerTitleAlign: "center",
          headerStyle: { backgroundColor: "#525FE1"}
        }}/>
      </Stack.Navigator>
    );
  }

  return (
      <NavigationContainer>
        <MyStack/>
    </NavigationContainer>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#fff",
    alignItems: "center",
    justifyContent: "center",
  },
});
