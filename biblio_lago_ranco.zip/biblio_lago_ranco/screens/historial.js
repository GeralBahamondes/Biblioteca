import React from 'react';
import { View, Text, FlatList, StyleSheet, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Book, Calendar, CheckCircle, XCircle } from 'lucide-react-native';

// Datos de muestra para las reservas
const reservas = [
  { id: '1', libro: 'Cien años de soledad', fecha: '2023-05-15', estado: 'Completada' },
  { id: '2', libro: 'El señor de los anillos', fecha: '2023-06-01', estado: 'En curso' },
  { id: '3', libro: '1984', fecha: '2023-06-10', estado: 'Cancelada' },
  { id: '4', libro: 'Orgullo y prejuicio', fecha: '2023-06-20', estado: 'En curso' },
  { id: '5', libro: 'Don Quijote de la Mancha', fecha: '2023-07-01', estado: 'Pendiente' },
];

const EstadoIcon = ({ estado }) => {
  switch (estado) {
    case 'Completada':
      return <CheckCircle color="green" size={24} />;
    case 'Cancelada':
      return <XCircle color="red" size={24} />;
    case 'En curso':
      return <Calendar color="blue" size={24} />;
    default:
      return <Calendar color="gray" size={24} />;
  }
};

const ReservaItem = ({ libro, fecha, estado }) => (
  <TouchableOpacity style={styles.reservaItem}>
    <View style={styles.reservaInfo}>
      <View style={styles.libroIconContainer}>
        <Book size={24} color="#666" />
      </View>
      <View style={styles.reservaTexto}>
        <Text style={styles.libroTitulo}>{libro}</Text>
        <Text style={styles.reservaFecha}>Reservado el: {fecha}</Text>
      </View>
    </View>
    <View style={styles.estadoContainer}>
      <EstadoIcon estado={estado} />
      <Text style={[styles.estadoTexto, { color: estado === 'Cancelada' ? 'red' : estado === 'Completada' ? 'green' : 'blue' }]}>
        {estado}
      </Text>
    </View>
  </TouchableOpacity>
);

export default function Component() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.titulo}>Historial de Reservas</Text>
      <FlatList
        data={reservas}
        renderItem={({ item }) => <ReservaItem {...item} />}
        keyExtractor={item => item.id}
        contentContainerStyle={styles.listaContenedor}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
    color: '#333',
  },
  listaContenedor: {
    padding: 10,
  },
  reservaItem: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 15,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  reservaInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  libroIconContainer: {
    marginRight: 15,
  },
  reservaTexto: {
    flex: 1,
  },
  libroTitulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
    marginBottom: 5,
  },
  reservaFecha: {
    fontSize: 14,
    color: '#666',
  },
  estadoContainer: {
    alignItems: 'center',
  },
  estadoTexto: {
    fontSize: 12,
    marginTop: 5,
    fontWeight: '500',
  },
});