import React from 'react';
import { View, Text, TouchableOpacity, StyleSheet } from 'react-native';
import { Book, Calendar, Clock } from 'lucide-react-native';

export default function home ({navigation}) {
  return (
    <View style={styles.container}>
      <View style={styles.buttonContainer}>
        <TouchableOpacity style={styles.button} onPress={() => {navigation.navigate("Reserva")}}>
          <Calendar style={styles.icon} />
          <Text style={styles.buttonText}>Reservar</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => {navigation.navigate("Libros")}}>
          <Book style={styles.icon} />
          <Text style={styles.buttonText}>Libros</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={() => {navigation.navigate("Historial")}}>
          <Clock style={styles.icon} />
          <Text style={styles.buttonText}>Historial</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 40,
    color: '#333',
  },
  buttonContainer: {
    width: '80%',
  },
  button: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#525FE1',
    padding: 30,
    borderRadius: 10,
    marginBottom: 100,
  },
  buttonText: {
    color: 'white',
    fontSize: 18,
    marginLeft: 10,
  },
  icon: {
    color: 'white',
  },
});