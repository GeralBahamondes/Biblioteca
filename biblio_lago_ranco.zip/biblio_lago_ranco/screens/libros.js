import React from 'react';
import { View, Text, FlatList, Image, StyleSheet, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';

// Datos de muestra para los libros
const libros = [
  { id: '1', titulo: 'Cien años de soledad', autor: 'Gabriel García Márquez', imagen: 'https://example.com/cien-anos.jpg' },
  { id: '2', titulo: 'El señor de los anillos', autor: 'J.R.R. Tolkien', imagen: 'https://example.com/senor-anillos.jpg' },
  { id: '3', titulo: '1984', autor: 'George Orwell', imagen: 'https://example.com/1984.jpg' },
  { id: '4', titulo: 'Orgullo y prejuicio', autor: 'Jane Austen', imagen: 'https://example.com/orgullo-prejuicio.jpg' },
  // Agrega más libros según sea necesario
];

const { width } = Dimensions.get('window');

const LibroItem = ({ titulo, autor, imagen }) => (
  <View style={styles.libroItem}>
    <Image source={{ uri: imagen }} style={styles.libroImagen} />
    <Text style={styles.libroTitulo}>{titulo}</Text>
    <Text style={styles.libroAutor}>{autor}</Text>
  </View>
);

export default function Component() {
  return (
    <SafeAreaView style={styles.container}>
      <Text style={styles.titulo}>Biblioteca</Text>
      <FlatList
        data={libros}
        renderItem={({ item }) => <LibroItem {...item} />}
        keyExtractor={item => item.id}
        numColumns={2}
        contentContainerStyle={styles.listaContenedor}
      />
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f0f0f0',
  },
  titulo: {
    fontSize: 24,
    fontWeight: 'bold',
    textAlign: 'center',
    marginVertical: 20,
  },
  listaContenedor: {
    padding: 10,
  },
  libroItem: {
    backgroundColor: 'white',
    borderRadius: 8,
    padding: 10,
    margin: 5,
    width: (width - 40) / 2,
    alignItems: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  libroImagen: {
    width: '100%',
    height: 150,
    borderRadius: 4,
    marginBottom: 10,
  },
  libroTitulo: {
    fontSize: 16,
    fontWeight: 'bold',
    textAlign: 'center',
    marginBottom: 5,
  },
  libroAutor: {
    fontSize: 14,
    color: '#666',
    textAlign: 'center',
  },
});