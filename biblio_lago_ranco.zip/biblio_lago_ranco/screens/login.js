import { StyleSheet, Text, View, Image, TouchableOpacity, TextInput} from "react-native";


export default function login ({navigation}) {
    return (
        <View style={styles.index}>

            <View>
                <Image source={require('../assets/foto.png')} style={styles.foto1} />
            </View>

            <View style={styles.tarjeta}>
                <View style={styles.texto}>
                    <TextInput placeholder="correo@ejemplo.com" style={{paddingHorizontal: 15}}/>
                </View>

                <View style={styles.texto}>
                    <TextInput placeholder="Password" style={{paddingHorizontal: 15}} secureTextEntry={true}/>
                </View>
                
                <View style={styles.Pboton}>
                    <TouchableOpacity style={styles.boton} onPress={() => {navigation.navigate("Home")}}>
                        <Text style={styles.TextBoton}>Ingresar</Text>
                    </TouchableOpacity>
                </View>
            </View>
        </View>
    )
  }

  const styles = StyleSheet.create({
    index:{
        flex:1,
        justifyContent: "center",
        alignItems: "center",
        backgroundColor: "white",
    },
    foto1:{
        width: 100,
        height: 100,
        borderRadius: 50,
        borderColor: "black",
    },
    tarjeta:{
        margin: 20,
        backgroundColor: "white",
        borderRadius: 20,
        width: "90%",
        padding: 20,
        shadowColor: "#000",
        shadowOffset: {
            width: 0,
            height: 2
        },
        shadowOpacity:0.25,
        shadowRadius:4,
        elevation:5,

    },
    texto: {
        paddingVertical: 20,
        backgroundColor: "#cccccc40",
        borderRadius: 30,
        marginVertical: 10
    },
    Pboton:{
        alignItems: "center",
    },
    boton:{
        backgroundColor:"#525fe1",
        borderRadius: 30,
        paddingVertical: 20,
        width: 150,
        marginTop: 20
    },
    TextBoton:{
        textAlign: "center",
        color:"white"
    }

    },
  );