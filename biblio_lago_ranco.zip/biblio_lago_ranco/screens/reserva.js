import React, { useState } from 'react';
import { View, Text, TextInput, FlatList, TouchableOpacity, StyleSheet } from 'react-native';
import { Search, Book, Calendar } from 'lucide-react-native';

// Datos de ejemplo para los libros
const librosDisponibles = [
  { id: '1', titulo: 'Cien años de soledad', autor: 'Gabriel García Márquez' },
  { id: '2', titulo: '1984', autor: 'George Orwell' },
  { id: '3', titulo: 'El principito', autor: 'Antoine de Saint-Exupéry' },
  // Añade más libros aquí
];

export default function Reserva() {
  const [busqueda, setBusqueda] = useState('');
  const [libroSeleccionado, setLibroSeleccionado] = useState(null);

  const renderLibro = ({ item }) => (
    <TouchableOpacity 
      style={[
        styles.libroItem, 
        libroSeleccionado?.id === item.id && styles.libroSeleccionado
      ]}
      onPress={() => setLibroSeleccionado(item)}
    >
      <Book style={styles.libroIcon} />
      <View>
        <Text style={styles.libroTitulo}>{item.titulo}</Text>
        <Text style={styles.libroAutor}>{item.autor}</Text>
      </View>
    </TouchableOpacity>
  );

  return (
    <View style={styles.container}>
      <Text style={styles.title}>Reservar Libro</Text>
      
      <View style={styles.searchContainer}>
        <Search style={styles.searchIcon} />
        <TextInput
          style={styles.searchInput}
          placeholder="Buscar libro..."
          value={busqueda}
          onChangeText={setBusqueda}
        />
      </View>

      <FlatList
        data={librosDisponibles.filter(libro => 
          libro.titulo.toLowerCase().includes(busqueda.toLowerCase()) ||
          libro.autor.toLowerCase().includes(busqueda.toLowerCase())
        )}
        renderItem={renderLibro}
        keyExtractor={item => item.id}
        style={styles.listaLibros}
      />

      <TouchableOpacity 
        style={[styles.botonReservar, !libroSeleccionado && styles.botonDeshabilitado]}
        disabled={!libroSeleccionado}
      >
        <Calendar style={styles.reservarIcon} />
        <Text style={styles.botonReservarTexto}>Confirmar Reserva</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    padding: 20,
    backgroundColor: '#f5f5f5',
  },
  title: {
    fontSize: 24,
    fontWeight: 'bold',
    marginBottom: 20,
    color: '#333',
  },
  searchContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    borderRadius: 10,
    padding: 10,
    marginBottom: 20,
  },
  searchIcon: {
    marginRight: 10,
    color: '#4a90e2',
  },
  searchInput: {
    flex: 1,
    fontSize: 16,
  },
  listaLibros: {
    flex: 1,
  },
  libroItem: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: 'white',
    padding: 15,
    borderRadius: 10,
    marginBottom: 10,
  },
  libroSeleccionado: {
    backgroundColor: '#e6f2ff',
    borderColor: '#4a90e2',
    borderWidth: 2,
  },
  libroIcon: {
    marginRight: 15,
    color: '#4a90e2',
  },
  libroTitulo: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#333',
  },
  libroAutor: {
    fontSize: 14,
    color: '#666',
  },
  botonReservar: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4a90e2',
    padding: 15,
    borderRadius: 10,
    marginTop: 20,
  },
  botonDeshabilitado: {
    backgroundColor: '#b3d4fc',
  },
  reservarIcon: {
    marginRight: 10,
    color: 'white',
  },
  botonReservarTexto: {
    color: 'white',
    fontSize: 18,
    fontWeight: 'bold',
  },
});