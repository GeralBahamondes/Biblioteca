from django.core.management.base import BaseCommand
from prestamos.views import verificar_prestamos_vencidos

class Command(BaseCommand):
    help = 'Verifica los préstamos vencidos y crea notificaciones'

    def handle(self, *args, **options):
        verificar_prestamos_vencidos()
        self.stdout.write(self.style.SUCCESS('Verificación de préstamos vencidos completada'))