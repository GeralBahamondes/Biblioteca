from django.db import models
from django.utils import timezone
from usuarios.models import Usuario
from libros.models import Libro

class Prestamo(models.Model):
    usuario = models.ForeignKey(Usuario, on_delete=models.CASCADE)
    libro = models.ForeignKey(Libro, on_delete=models.CASCADE)
    fecha_prestamo = models.DateField(auto_now_add=True)
    fecha_devolucion = models.DateField()
    devuelto = models.BooleanField(default=False)

    def __str__(self):
        return f"{self.usuario.username} - {self.libro.titulo}"

    def esta_vencido(self):
        return timezone.now().date() > self.fecha_devolucion