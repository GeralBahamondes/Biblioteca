from django.urls import path
from . import views

urlpatterns = [
    path('solicitar/<int:libro_id>/', views.solicitar_prestamo, name='solicitar_prestamo'),
    path('mis-prestamos/', views.mis_prestamos, name='mis_prestamos'),
    path('devolver/<int:prestamo_id>/', views.devolver_libro, name='devolver_libro'),
]