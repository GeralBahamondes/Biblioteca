from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from django.utils import timezone
from .models import Prestamo
from libros.models import Libro
from usuarios.models import Notificacion

@login_required
def solicitar_prestamo(request, libro_id):
    libro = get_object_or_404(Libro, id=libro_id)
    if libro.cantidad_disponible > 0:
        fecha_devolucion = timezone.now().date() + timezone.timedelta(days=14)
        Prestamo.objects.create(usuario=request.user, libro=libro, fecha_devolucion=fecha_devolucion)
        libro.cantidad_disponible -= 1
        libro.save()
        return redirect('lista_libros')
    return render(request, 'prestamos/error_prestamo.html', {'mensaje': 'El libro no está disponible'})

@login_required
def mis_prestamos(request):
    prestamos = Prestamo.objects.filter(usuario=request.user, devuelto=False)
    return render(request, 'prestamos/mis_prestamos.html', {'prestamos': prestamos})

@login_required
def devolver_libro(request, prestamo_id):
    prestamo = get_object_or_404(Prestamo, id=prestamo_id, usuario=request.user)
    if request.method == 'POST':
        prestamo.devuelto = True
        prestamo.save()
        prestamo.libro.cantidad_disponible += 1
        prestamo.libro.save()
        return redirect('mis_prestamos')
    return render(request, 'prestamos/confirmar_devolucion.html', {'prestamo': prestamo})

def verificar_prestamos_vencidos():
    prestamos_vencidos = Prestamo.objects.filter(devuelto=False, fecha_devolucion__lt=timezone.now().date())
    for prestamo in prestamos_vencidos:
        Notificacion.objects.create(
            usuario=prestamo.usuario,
            mensaje=f"El préstamo del libro '{prestamo.libro.titulo}' está vencido. Por favor, devuélvalo lo antes posible."
        )