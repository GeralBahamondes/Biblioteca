from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Usuario

class RegistroForm(UserCreationForm):
    class Meta:
        model = Usuario
        fields = ['username', 'RUT', 'email', 'direccion', 'telefono', 'password1', 'password2']

class LoginForm(forms.Form):
    rut = forms.CharField(max_length=12)
    password = forms.CharField(widget=forms.PasswordInput)