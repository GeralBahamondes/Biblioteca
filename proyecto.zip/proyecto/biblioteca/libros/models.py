
from django.db import models

class Libro(models.Model):
    titulo = models.CharField(max_length=255)
    autor = models.CharField(max_length=255)
    isbn = models.CharField(max_length=13, unique=True)
    descripcion = models.TextField()
    imagen = models.ImageField(upload_to='libros/')
    disponible = models.BooleanField(default=True)

    def __str__(self):
        return self.titulo
