
from django.urls import path
from . import views

urlpatterns = [
    path('', views.listar_prestamos, name='listar_prestamos'),
    path('registrar/', views.registrar_prestamo, name='registrar_prestamo'),
    path('devolver/<int:prestamo_id>/', views.devolver_prestamo, name='devolver_prestamo'),
]
