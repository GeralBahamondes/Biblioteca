
from django.shortcuts import render, redirect, get_object_or_404
from .models import Prestamo
from .forms import PrestamoForm
from libros.models import Libro
from django.utils import timezone

def listar_prestamos(request):
    prestamos = Prestamo.objects.all()
    return render(request, 'prestamos/listar_prestamos.html', {'prestamos': prestamos})

def registrar_prestamo(request):
    if request.method == 'POST':
        form = PrestamoForm(request.POST)
        if form.is_valid():
            prestamo = form.save(commit=False)
            prestamo.save()
            prestamo.libro.disponible = False
            prestamo.libro.save()
            return redirect('listar_prestamos')
    else:
        form = PrestamoForm()
    return render(request, 'prestamos/registrar_prestamo.html', {'form': form})

def devolver_prestamo(request, prestamo_id):
    prestamo = get_object_or_404(Prestamo, id=prestamo_id)
    prestamo.devuelto = True
    prestamo.fecha_devolucion = timezone.now()
    prestamo.libro.disponible = True
    prestamo.libro.save()
    prestamo.save()
    return redirect('listar_prestamos')
