from django import forms
from django.contrib.auth.forms import UserCreationForm
from .models import Usuario

class RegistroForm(UserCreationForm):
    class Meta:
        model = Usuario
        fields = ['username', 'rut', 'email', 'telefono', 'direccion', 'password1', 'password2']

    def clean_rut(self):
        rut = self.cleaned_data.get('rut')
        if not rut: 
            raise forms.ValidationError("Este campo es obligatorio.")
        
       
        if not self.instance.validar_rut(rut): 
            raise forms.ValidationError("El RUT ingresado no es válido.")

        return rut

    def save(self, commit=True):
        user = super().save(commit=False)
        user.set_password(self.cleaned_data["password1"])  
        if commit:
            user.save()
        return user
