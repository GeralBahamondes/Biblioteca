from django.contrib.auth.models import AbstractUser
from django.core.exceptions import ValidationError
from django.db import models

def validar_rut(rut):
    """Función para validar RUT chileno."""
    rut = rut.replace(' ', '').replace('.', '').replace('-', '')
    
    if len(rut) < 2:
        return False
    
    rut_body = rut[:-1]
    dv = rut[-1].upper()

    suma = 0
    multiplicador = 2
    
    for digit in reversed(rut_body):
        suma += int(digit) * multiplicador
        multiplicador = 9 if multiplicador == 7 else multiplicador + 1

    dv_calculado = 11 - (suma % 11)
    if dv_calculado == 11:
        dv_calculado = '0'
    elif dv_calculado == 10:
        dv_calculado = 'K'

    return dv == str(dv_calculado)

class Usuario(AbstractUser):
    ROL_CHOICES = [
        ('admin', 'Administrador'),
        ('biblio', 'Bibliotecario'),
        ('user', 'Usuario Normal'),
    ]
    rut = models.CharField(max_length=12, unique=True)  # Usamos CharField

    rol = models.CharField(max_length=10, choices=ROL_CHOICES)
    telefono = models.CharField(max_length=20)
    direccion = models.TextField(blank=True, null=True)

    def clean(self):
        super().clean()
        if not validar_rut(self.rut):  # Validación del RUT
            raise ValidationError(f'El RUT {self.rut} no es válido.')

    def __str__(self):
        return f"{self.username} - {self.get_rol_display()}"
