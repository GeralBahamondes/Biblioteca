from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from .models import Usuario

class RegistroForm(UserCreationForm):
    class Meta:
        model = Usuario
        fields = ['nombre', 'telefono', 'email', 'rut', 'fecha_nacimiento', 'direccion', 'password1', 'password2']
        labels = {
            'nombre': 'Nombre',
            'telefono': 'Número Telefónico',
            'email': 'Correo Electrónico',
            'rut': 'RUT',
            'fecha_nacimiento': 'Fecha de Nacimiento',
            'direccion': 'Dirección',
            'password1': 'Contraseña', 
            'password2': 'Confirmar Contraseña',  
        }
        help_texts = {
            'password1': 'La contraseña debe tener al menos 8 caracteres.',
            'password2': 'Ingresa la misma contraseña que antes, para verificación.',
        }

class LoginForm(AuthenticationForm):
    username = forms.EmailField(label='Correo Electrónico', max_length=100)
    password = forms.CharField(label='Contraseña', widget=forms.PasswordInput)

    class Meta:
        model = Usuario
        fields = ['username', 'password']

    def clean(self):
        cleaned_data = super().clean()
        email = cleaned_data.get("username")
        password = cleaned_data.get("password")
        return cleaned_data
