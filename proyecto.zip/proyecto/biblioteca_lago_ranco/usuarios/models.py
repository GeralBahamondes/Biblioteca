from django.db import models
from django.contrib.auth.models import AbstractBaseUser, BaseUserManager

class UsuarioManager(BaseUserManager):
    def create_user(self, email, nombre, telefono, rut, fecha_nacimiento, direccion, password=None):
        if not email:
            raise ValueError('El usuario debe tener un correo electrónico')
        if not rut or not self.validar_rut(rut):
            raise ValueError('El RUT es inválido')

        usuario = self.model(
            email=self.normalize_email(email),
            nombre=nombre,
            telefono=telefono,
            rut=rut,
            fecha_nacimiento=fecha_nacimiento,
            direccion=direccion,
        )
        usuario.set_password(password)
        usuario.save(using=self._db)
        return usuario

    def validar_rut(self, rut):
      
        rut = rut.replace('.', '').replace('-', '')

       
        if len(rut) < 2:
            return False

        
        cuerpo = rut[:-1]
        digito_verificador = rut[-1].upper()

      
        suma = 0
        multiplicador = 2
        for i in range(len(cuerpo) - 1, -1, -1):
            suma += int(cuerpo[i]) * multiplicador
            multiplicador = 9 if multiplicador == 7 else multiplicador + 1

        resto = suma % 11
        if resto == 0:
            dv_calculado = '0'
        elif resto == 1:
            dv_calculado = 'K'
        else:
            dv_calculado = str(11 - resto)

        return dv_calculado == digito_verificador

class Usuario(AbstractBaseUser):
    nombre = models.CharField(max_length=255)
    telefono = models.CharField(max_length=15)
    email = models.EmailField(unique=True)
    rut = models.CharField(max_length=12, unique=True)
    fecha_nacimiento = models.DateField()
    direccion = models.CharField(max_length=255)

    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = ['nombre', 'rut', 'telefono', 'fecha_nacimiento', 'direccion']

    objects = UsuarioManager()

    def __str__(self):
        return self.email
