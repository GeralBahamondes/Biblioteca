from django.urls import path
from .views import registro, user_login, index

urlpatterns = [
    path('registro/', registro, name='registro'),
    path('login/', user_login, name='login'),
    path('', index, name='index'),
]
